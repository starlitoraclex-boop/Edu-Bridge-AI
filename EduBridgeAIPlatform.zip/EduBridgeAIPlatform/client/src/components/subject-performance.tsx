import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Calculator, FlaskConical, Book, Globe, LucideIcon } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface SubjectPerformanceItem {
  subject: string;
  score: number;
  icon: string;
  color: string;
}

const iconMap: Record<string, LucideIcon> = {
  calculator: Calculator,
  flask: FlaskConical,
  book: Book,
  globe: Globe,
};

const colorMap: Record<string, string> = {
  blue: "text-blue-500",
  green: "text-green-500", 
  purple: "text-purple-500",
  orange: "text-orange-500",
};

export default function SubjectPerformance() {
  const { data: performance = [], isLoading } = useQuery<SubjectPerformanceItem[]>({
    queryKey: ["/api/analytics/subject-performance"],
  });

  if (isLoading) {
    return (
      <Card data-testid="subject-performance-loading">
        <CardHeader>
          <CardTitle>Subject Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-muted rounded mb-2"></div>
                <div className="h-2 bg-muted rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="subject-performance">
      <CardHeader>
        <CardTitle>Subject Performance</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {performance.map((subject: SubjectPerformanceItem) => {
            const Icon = iconMap[subject.icon];
            const colorClass = colorMap[subject.color];
            
            return (
              <div key={subject.subject} data-testid={`subject-${subject.subject}`}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {Icon && <Icon className={`w-4 h-4 ${colorClass}`} />}
                    <span className="text-sm font-medium capitalize">
                      {subject.subject.replace('-', ' ')}
                    </span>
                  </div>
                  <span className="text-sm text-muted-foreground">{subject.score}%</span>
                </div>
                <Progress value={subject.score} className="h-2" />
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
