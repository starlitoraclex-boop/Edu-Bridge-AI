import { Link, useLocation } from "wouter";
import { GraduationCap, Home, Bot, Edit, ClipboardList, BarChart3, Calculator, FlaskConical, Book, Globe, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "AI Tutor Chat", href: "/ai-tutor", icon: Bot },
  { name: "Content Creator", href: "/content-creator", icon: Edit },
  { name: "Quiz Builder", href: "/quiz-builder", icon: ClipboardList },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
];

const subjects = [
  { name: "Mathematics", href: "/subjects/mathematics", icon: Calculator, color: "text-blue-500" },
  { name: "Science", href: "/subjects/science", icon: FlaskConical, color: "text-green-500" },
  { name: "Language Arts", href: "/subjects/language-arts", icon: Book, color: "text-purple-500" },
  { name: "History", href: "/subjects/history", icon: Globe, color: "text-orange-500" },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar">
      {/* Logo and Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <GraduationCap className="text-primary-foreground text-lg" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">EduBridgeAI</h1>
            <p className="text-sm text-muted-foreground">AI Education Platform</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.name} href={item.href}>
              <div
                className={cn(
                  "flex items-center space-x-3 p-3 rounded-lg transition-colors cursor-pointer",
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
                data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.name}</span>
              </div>
            </Link>
          );
        })}
        
        <div className="pt-4">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
            Subjects
          </h3>
          
          {subjects.map((subject) => (
            <Link key={subject.name} href={subject.href}>
              <div
                className="flex items-center space-x-3 p-2 rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground transition-colors cursor-pointer"
                data-testid={`subject-${subject.name.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <subject.icon className={cn("w-4 h-4", subject.color)} />
                <span className="text-sm">{subject.name}</span>
              </div>
            </Link>
          ))}
        </div>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted transition-colors cursor-pointer" data-testid="user-profile">
          <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
            <span className="text-sm font-medium text-secondary-foreground">JD</span>
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium">John Doe</p>
            <p className="text-xs text-muted-foreground">Educator</p>
          </div>
          <Settings className="w-4 h-4 text-muted-foreground hover:text-foreground" />
        </div>
      </div>
    </aside>
  );
}
