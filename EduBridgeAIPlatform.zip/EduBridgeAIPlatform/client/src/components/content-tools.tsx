import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Presentation, HelpCircle, FileText, Lightbulb } from "lucide-react";

const tools = [
  {
    id: "lesson-planner",
    name: "Lesson Planner",
    description: "Generate comprehensive lesson plans for any subject and grade level.",
    icon: Presentation,
    color: "bg-primary/10 text-primary",
  },
  {
    id: "quiz-generator",
    name: "Quiz Generator", 
    description: "Create adaptive quizzes with varied question types and difficulty levels.",
    icon: HelpCircle,
    color: "bg-secondary/10 text-secondary",
  },
  {
    id: "worksheet-maker",
    name: "Worksheet Maker",
    description: "Design interactive worksheets with auto-grading capabilities.",
    icon: FileText,
    color: "bg-accent/10 text-accent",
  },
  {
    id: "explanation-engine",
    name: "Explanation Engine",
    description: "Generate clear, step-by-step explanations for complex concepts.",
    icon: Lightbulb,
    color: "bg-chart-1/10 text-chart-1",
  },
];

interface ContentToolsProps {
  onToolSelect?: (toolId: string) => void;
}

export default function ContentTools({ onToolSelect }: ContentToolsProps) {
  return (
    <Card data-testid="content-tools">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>AI Content Creation Tools</CardTitle>
            <p className="text-muted-foreground">Generate educational materials powered by AI</p>
          </div>
          <Button variant="outline" data-testid="view-all-tools">
            View All Tools
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {tools.map((tool) => (
            <div
              key={tool.id}
              className="p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
              onClick={() => onToolSelect?.(tool.id)}
              data-testid={`tool-${tool.id}`}
            >
              <div className={`w-12 h-12 ${tool.color} rounded-lg flex items-center justify-center mb-3`}>
                <tool.icon className="w-6 h-6" />
              </div>
              <h4 className="font-medium mb-2">{tool.name}</h4>
              <p className="text-sm text-muted-foreground">{tool.description}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
