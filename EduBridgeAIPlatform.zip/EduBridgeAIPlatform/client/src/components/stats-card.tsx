import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  change: string;
  changeLabel: string;
  iconBgColor?: string;
}

export default function StatsCard({ 
  title, 
  value, 
  icon: Icon, 
  change, 
  changeLabel, 
  iconBgColor = "bg-primary/10" 
}: StatsCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow" data-testid={`stats-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold text-foreground">{value}</p>
          </div>
          <div className={`w-12 h-12 ${iconBgColor} rounded-lg flex items-center justify-center`}>
            <Icon className="text-primary" />
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm">
          <span className="text-secondary font-medium">{change}</span>
          <span className="text-muted-foreground ml-1">{changeLabel}</span>
        </div>
      </CardContent>
    </Card>
  );
}
