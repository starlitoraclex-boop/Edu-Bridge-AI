import { useState } from "react";
import Sidebar from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Wand2, FileText, Download } from "lucide-react";

const contentTypes = [
  { value: "lesson-plan", label: "Lesson Plan" },
  { value: "worksheet", label: "Worksheet" },
  { value: "explanation", label: "Explanation" },
];

const subjects = [
  { value: "mathematics", label: "Mathematics" },
  { value: "science", label: "Science" },
  { value: "language-arts", label: "Language Arts" },
  { value: "history", label: "History" },
];

export default function ContentCreator() {
  const [formData, setFormData] = useState({
    type: "",
    subject: "",
    topic: "",
    gradeLevel: "",
  });
  const [generatedContent, setGeneratedContent] = useState<any>(null);
  const { toast } = useToast();

  const generateMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/ai/generate-content", data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedContent(data);
      toast({
        title: "Content Generated!",
        description: "Your educational content has been created successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate content. Please try again.",
        variant: "destructive",
      });
      console.error("Content generation error:", error);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.type || !formData.subject || !formData.topic) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const downloadContent = () => {
    if (!generatedContent) return;
    
    const content = `${generatedContent.title}\n\n${generatedContent.content}`;
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${generatedContent.title.replace(/\s+/g, "_")}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4" data-testid="content-creator-header">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Content Creator</h2>
            <p className="text-muted-foreground">Generate educational materials with AI</p>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Generation Form */}
            <Card data-testid="content-form">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Wand2 className="w-5 h-5 mr-2" />
                  Generate Content
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="content-type">Content Type *</Label>
                    <Select 
                      value={formData.type} 
                      onValueChange={(value) => handleInputChange("type", value)}
                    >
                      <SelectTrigger data-testid="content-type-select">
                        <SelectValue placeholder="Select content type" />
                      </SelectTrigger>
                      <SelectContent>
                        {contentTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject *</Label>
                    <Select 
                      value={formData.subject} 
                      onValueChange={(value) => handleInputChange("subject", value)}
                    >
                      <SelectTrigger data-testid="subject-select">
                        <SelectValue placeholder="Select subject" />
                      </SelectTrigger>
                      <SelectContent>
                        {subjects.map((subject) => (
                          <SelectItem key={subject.value} value={subject.value}>
                            {subject.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="topic">Topic *</Label>
                    <Input
                      id="topic"
                      value={formData.topic}
                      onChange={(e) => handleInputChange("topic", e.target.value)}
                      placeholder="e.g., Quadratic Equations, Photosynthesis, etc."
                      data-testid="topic-input"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="grade-level">Grade Level (Optional)</Label>
                    <Input
                      id="grade-level"
                      value={formData.gradeLevel}
                      onChange={(e) => handleInputChange("gradeLevel", e.target.value)}
                      placeholder="e.g., 9th Grade, High School, etc."
                      data-testid="grade-level-input"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={generateMutation.isPending}
                    data-testid="generate-content"
                  >
                    {generateMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-4 h-4 mr-2" />
                        Generate Content
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Generated Content Display */}
            <Card data-testid="generated-content">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <FileText className="w-5 h-5 mr-2" />
                    Generated Content
                  </CardTitle>
                  {generatedContent && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={downloadContent}
                      data-testid="download-content"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {generateMutation.isPending ? (
                  <div className="flex items-center justify-center h-64">
                    <div className="text-center">
                      <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-primary" />
                      <p className="text-muted-foreground">Generating your content...</p>
                    </div>
                  </div>
                ) : generatedContent ? (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">{generatedContent.title}</h3>
                      {generatedContent.metadata && (
                        <div className="flex flex-wrap gap-2 mb-4">
                          <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded">
                            {generatedContent.type}
                          </span>
                          <span className="px-2 py-1 bg-secondary/10 text-secondary text-xs rounded">
                            {generatedContent.metadata.subject}
                          </span>
                          {generatedContent.metadata.difficulty && (
                            <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded">
                              {generatedContent.metadata.difficulty}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    <Textarea
                      value={generatedContent.content}
                      readOnly
                      className="min-h-[400px] resize-none"
                      data-testid="content-display"
                    />
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-64 text-center">
                    <div>
                      <FileText className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                      <p className="text-muted-foreground">
                        Fill out the form and click "Generate Content" to create educational materials.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
