import Sidebar from "@/components/sidebar";
import StatsCard from "@/components/stats-card";
import SubjectPerformance from "@/components/subject-performance";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Users, Bot, ClipboardList, TrendingUp, Activity, Clock, Award, Target } from "lucide-react";
import { useState } from "react";

interface UserStats {
  activeStudents: number;
  aiInteractions: number;
  quizzesCreated: number;
  avgScore: number;
}

interface RecentActivity {
  id: string;
  type: string;
  title: string;
  description: string;
  icon: string;
  color: string;
}

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("7d");

  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ["/api/user/stats"],
  });

  const { data: recentActivity = [], isLoading: activityLoading } = useQuery<RecentActivity[]>({
    queryKey: ["/api/analytics/recent-activity"],
  });

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4" data-testid="analytics-header">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Analytics</h2>
              <p className="text-muted-foreground">Track learning progress and platform usage</p>
            </div>
            
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-48" data-testid="time-range-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1d">Last 24 hours</SelectItem>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Overview Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statsLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <Card key={i} className="animate-pulse" data-testid="analytics-stats-loading">
                  <CardContent className="p-6">
                    <div className="h-16 bg-muted rounded"></div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <>
                <StatsCard
                  title="Active Students"
                  value={stats?.activeStudents || 0}
                  icon={Users}
                  change="+12%"
                  changeLabel="from last period"
                  iconBgColor="bg-primary/10"
                />
                <StatsCard
                  title="AI Interactions"
                  value={stats?.aiInteractions || 0}
                  icon={Bot}
                  change="+28%"
                  changeLabel="from last period"
                  iconBgColor="bg-accent/10"
                />
                <StatsCard
                  title="Content Created"
                  value={stats?.quizzesCreated || 0}
                  icon={ClipboardList}
                  change="+8%"
                  changeLabel="from last period"
                  iconBgColor="bg-secondary/10"
                />
                <StatsCard
                  title="Avg. Performance"
                  value={`${stats?.avgScore || 0}%`}
                  icon={TrendingUp}
                  change="+3.2%"
                  changeLabel="improvement"
                  iconBgColor="bg-chart-1/10"
                />
              </>
            )}
          </div>

          {/* Detailed Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Usage Metrics */}
            <Card className="lg:col-span-2" data-testid="usage-metrics">
              <CardHeader>
                <CardTitle>Usage Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <Activity className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">Total Sessions</p>
                          <p className="text-2xl font-bold">1,247</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-secondary">+15%</p>
                        <p className="text-xs text-muted-foreground">vs last period</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                          <Clock className="w-5 h-5 text-accent" />
                        </div>
                        <div>
                          <p className="font-medium">Avg. Session Time</p>
                          <p className="text-2xl font-bold">24m</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-secondary">+8%</p>
                        <p className="text-xs text-muted-foreground">vs last period</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center">
                          <Award className="w-5 h-5 text-secondary" />
                        </div>
                        <div>
                          <p className="font-medium">Completion Rate</p>
                          <p className="text-2xl font-bold">87%</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-secondary">+5%</p>
                        <p className="text-xs text-muted-foreground">vs last period</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-chart-1/10 rounded-lg flex items-center justify-center">
                          <Target className="w-5 h-5 text-chart-1" />
                        </div>
                        <div>
                          <p className="font-medium">Success Rate</p>
                          <p className="text-2xl font-bold">92%</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-secondary">+3%</p>
                        <p className="text-xs text-muted-foreground">vs last period</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Subject Performance */}
            <SubjectPerformance />
          </div>

          {/* Learning Progress & Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            {/* Learning Progress */}
            <Card data-testid="learning-progress">
              <CardHeader>
                <CardTitle>Learning Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Weekly Learning Goals</span>
                      <span>75%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{ width: "75%" }}></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Quiz Completion</span>
                      <span>90%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-secondary h-2 rounded-full" style={{ width: "90%" }}></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Content Creation</span>
                      <span>60%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-accent h-2 rounded-full" style={{ width: "60%" }}></div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>AI Interaction Quality</span>
                      <span>95%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-chart-1 h-2 rounded-full" style={{ width: "95%" }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card data-testid="analytics-recent-activity">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activityLoading ? (
                    Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="flex items-start space-x-3">
                          <div className="w-8 h-8 bg-muted rounded-full"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-muted rounded mb-1"></div>
                            <div className="h-3 bg-muted rounded w-2/3"></div>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    recentActivity.map((activity: any) => (
                      <div key={activity.id} className="flex items-start space-x-3" data-testid={`analytics-activity-${activity.id}`}>
                        <div className={`w-8 h-8 bg-${activity.color}/10 rounded-full flex items-center justify-center flex-shrink-0`}>
                          {activity.icon === "file-alt" && <ClipboardList className={`text-${activity.color} w-4 h-4`} />}
                          {activity.icon === "user-graduate" && <Users className={`text-${activity.color} w-4 h-4`} />}
                          {activity.icon === "robot" && <Bot className={`text-${activity.color} w-4 h-4`} />}
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{activity.title}</p>
                          <p className="text-xs text-muted-foreground">{activity.description}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
