import Sidebar from "@/components/sidebar";
import ChatInterface from "@/components/chat-interface";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";

const subjects = [
  { value: "mathematics", label: "Mathematics" },
  { value: "science", label: "Science" },
  { value: "language-arts", label: "Language Arts" },
  { value: "history", label: "History" },
];

export default function AITutor() {
  const [selectedSubject, setSelectedSubject] = useState<string | undefined>();

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4" data-testid="ai-tutor-header">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground">AI Tutor</h2>
              <p className="text-muted-foreground">Get personalized help with your studies</p>
            </div>
            
            <div className="flex items-center space-x-4">
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="w-48" data-testid="subject-select">
                  <SelectValue placeholder="Select subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject.value} value={subject.value}>
                      {subject.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button variant="outline" data-testid="new-session">
                New Session
              </Button>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 h-full">
            {/* Main Chat */}
            <div className="xl:col-span-3">
              <ChatInterface 
                subject={selectedSubject} 
                className="h-full"
              />
            </div>

            {/* Sidebar Info */}
            <div className="space-y-6">
              {/* Subject Info */}
              {selectedSubject && (
                <Card data-testid="subject-info">
                  <CardHeader>
                    <CardTitle>
                      {subjects.find(s => s.value === selectedSubject)?.label}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">
                      I'm specialized in helping with {selectedSubject.replace('-', ' ')} topics. 
                      Feel free to ask about concepts, problems, or homework.
                    </p>
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">I can help with:</h4>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        {selectedSubject === "mathematics" && (
                          <>
                            <li>• Algebra and equations</li>
                            <li>• Geometry and trigonometry</li>
                            <li>• Calculus fundamentals</li>
                            <li>• Problem-solving strategies</li>
                          </>
                        )}
                        {selectedSubject === "science" && (
                          <>
                            <li>• Physics concepts</li>
                            <li>• Chemistry equations</li>
                            <li>• Biology processes</li>
                            <li>• Lab procedures</li>
                          </>
                        )}
                        {selectedSubject === "language-arts" && (
                          <>
                            <li>• Reading comprehension</li>
                            <li>• Writing techniques</li>
                            <li>• Grammar and syntax</li>
                            <li>• Literary analysis</li>
                          </>
                        )}
                        {selectedSubject === "history" && (
                          <>
                            <li>• Historical events</li>
                            <li>• Cause and effect</li>
                            <li>• Timeline analysis</li>
                            <li>• Primary sources</li>
                          </>
                        )}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Quick Actions */}
              <Card data-testid="tutor-quick-actions">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-sm"
                      data-testid="explain-concept"
                    >
                      Explain a concept
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-sm"
                      data-testid="solve-problem"
                    >
                      Solve a problem
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-sm"
                      data-testid="practice-questions"
                    >
                      Practice questions
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start text-sm"
                      data-testid="homework-help"
                    >
                      Homework help
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Tips */}
              <Card data-testid="tutor-tips">
                <CardHeader>
                  <CardTitle>Tips for Better Learning</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm text-muted-foreground space-y-2">
                    <li>• Be specific about what you're struggling with</li>
                    <li>• Ask for step-by-step explanations</li>
                    <li>• Request practice problems</li>
                    <li>• Don't hesitate to ask follow-up questions</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
