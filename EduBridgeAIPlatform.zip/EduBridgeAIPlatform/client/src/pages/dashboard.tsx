import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import ChatInterface from "@/components/chat-interface";
import StatsCard from "@/components/stats-card";
import SubjectPerformance from "@/components/subject-performance";
import ContentTools from "@/components/content-tools";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Bot, ClipboardList, TrendingUp, Search, Bell, Plus, Wand2, BarChart3, FileText, GraduationCap } from "lucide-react";

interface UserStats {
  activeStudents: number;
  aiInteractions: number;
  quizzesCreated: number;
  avgScore: number;
}

interface RecentActivity {
  id: string;
  type: string;
  title: string;
  description: string;
  icon: string;
  color: string;
}

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ["/api/user/stats"],
  });

  const { data: recentActivity = [], isLoading: activityLoading } = useQuery<RecentActivity[]>({
    queryKey: ["/api/analytics/recent-activity"],
  });

  const handleToolSelect = (toolId: string) => {
    console.log("Selected tool:", toolId);
    // Navigate to appropriate tool page
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4" data-testid="dashboard-header">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Dashboard</h2>
              <p className="text-muted-foreground">Welcome back! Here's your learning overview.</p>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input 
                  placeholder="Search..." 
                  className="pl-10 pr-4 py-2 w-64"
                  data-testid="search-input"
                />
              </div>
              
              {/* Notifications */}
              <Button variant="outline" size="icon" className="relative" data-testid="notifications">
                <Bell className="w-4 h-4" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-destructive rounded-full"></span>
              </Button>
              
              {/* AI Assistant Toggle */}
              <Button className="bg-accent text-accent-foreground hover:bg-accent/90" data-testid="ai-assistant">
                <Bot className="w-4 h-4 mr-2" />
                AI Assistant
              </Button>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statsLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <Card key={i} className="animate-pulse" data-testid="stats-loading">
                  <CardContent className="p-6">
                    <div className="h-16 bg-muted rounded"></div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <>
                <StatsCard
                  title="Active Students"
                  value={stats?.activeStudents || 0}
                  icon={Users}
                  change="+12%"
                  changeLabel="from last month"
                  iconBgColor="bg-primary/10"
                />
                <StatsCard
                  title="AI Interactions"
                  value={stats?.aiInteractions || 0}
                  icon={Bot}
                  change="+28%"
                  changeLabel="from last week"
                  iconBgColor="bg-accent/10"
                />
                <StatsCard
                  title="Quizzes Created"
                  value={stats?.quizzesCreated || 0}
                  icon={ClipboardList}
                  change="+8%"
                  changeLabel="this month"
                  iconBgColor="bg-secondary/10"
                />
                <StatsCard
                  title="Avg. Score"
                  value={`${stats?.avgScore || 0}%`}
                  icon={TrendingUp}
                  change="+3.2%"
                  changeLabel="improvement"
                  iconBgColor="bg-chart-1/10"
                />
              </>
            )}
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* AI Chat Interface */}
            <div className="lg:col-span-2">
              <ChatInterface className="h-96" />
            </div>

            {/* Quick Actions & Analytics */}
            <div className="space-y-6">
              {/* Quick Actions */}
              <Card data-testid="quick-actions">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button 
                      className="w-full justify-start bg-primary/10 text-primary hover:bg-primary/20" 
                      variant="ghost"
                      data-testid="create-quiz"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create New Quiz
                    </Button>
                    
                    <Button 
                      className="w-full justify-start bg-secondary/10 text-secondary hover:bg-secondary/20" 
                      variant="ghost"
                      data-testid="generate-content"
                    >
                      <Wand2 className="w-4 h-4 mr-2" />
                      Generate Content
                    </Button>
                    
                    <Button 
                      className="w-full justify-start bg-accent/10 text-accent hover:bg-accent/20" 
                      variant="ghost"
                      data-testid="analyze-progress"
                    >
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Analyze Progress
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card data-testid="recent-activity">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {activityLoading ? (
                      Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="animate-pulse">
                          <div className="flex items-start space-x-3">
                            <div className="w-8 h-8 bg-muted rounded-full"></div>
                            <div className="flex-1">
                              <div className="h-4 bg-muted rounded mb-1"></div>
                              <div className="h-3 bg-muted rounded w-2/3"></div>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      recentActivity.map((activity: any) => (
                        <div key={activity.id} className="flex items-start space-x-3" data-testid={`activity-${activity.id}`}>
                          <div className={`w-8 h-8 bg-${activity.color}/10 rounded-full flex items-center justify-center flex-shrink-0`}>
                            {activity.icon === "file-alt" && <FileText className={`text-${activity.color} text-sm w-4 h-4`} />}
                            {activity.icon === "user-graduate" && <GraduationCap className={`text-${activity.color} text-sm w-4 h-4`} />}
                            {activity.icon === "robot" && <Bot className={`text-${activity.color} text-sm w-4 h-4`} />}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">{activity.title}</p>
                            <p className="text-xs text-muted-foreground">{activity.description}</p>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Subject Performance */}
              <SubjectPerformance />
            </div>
          </div>

          {/* Content Creation Tools */}
          <div className="mt-8">
            <ContentTools onToolSelect={handleToolSelect} />
          </div>
        </div>
      </main>
    </div>
  );
}
