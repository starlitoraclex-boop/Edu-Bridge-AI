import { useState } from "react";
import Sidebar from "@/components/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus, HelpCircle, Trash2, Edit } from "lucide-react";

const subjects = [
  { value: "mathematics", label: "Mathematics" },
  { value: "science", label: "Science" },
  { value: "language-arts", label: "Language Arts" },
  { value: "history", label: "History" },
];

const difficulties = [
  { value: "easy", label: "Easy" },
  { value: "medium", label: "Medium" },
  { value: "hard", label: "Hard" },
];

interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export default function QuizBuilder() {
  const [formData, setFormData] = useState({
    subject: "",
    difficulty: "",
    numQuestions: "5",
    topic: "",
  });
  const [generatedQuiz, setGeneratedQuiz] = useState<any>(null);
  const { toast } = useToast();

  const { data: quizzes = [], refetch } = useQuery<any[]>({
    queryKey: ["/api/quizzes"],
  });

  const generateMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const response = await apiRequest("POST", "/api/ai/generate-quiz", {
        ...data,
        numQuestions: parseInt(data.numQuestions),
      });
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedQuiz(data);
      refetch();
      toast({
        title: "Quiz Generated!",
        description: "Your quiz has been created successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate quiz. Please try again.",
        variant: "destructive",
      });
      console.error("Quiz generation error:", error);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subject || !formData.difficulty) {
      toast({
        title: "Missing Information",
        description: "Please select subject and difficulty.",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4" data-testid="quiz-builder-header">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Quiz Builder</h2>
            <p className="text-muted-foreground">Create AI-powered quizzes and assessments</p>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Quiz Generation Form */}
            <Card data-testid="quiz-form">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Plus className="w-5 h-5 mr-2" />
                  Generate New Quiz
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject *</Label>
                    <Select 
                      value={formData.subject} 
                      onValueChange={(value) => handleInputChange("subject", value)}
                    >
                      <SelectTrigger data-testid="quiz-subject-select">
                        <SelectValue placeholder="Select subject" />
                      </SelectTrigger>
                      <SelectContent>
                        {subjects.map((subject) => (
                          <SelectItem key={subject.value} value={subject.value}>
                            {subject.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="difficulty">Difficulty *</Label>
                    <Select 
                      value={formData.difficulty} 
                      onValueChange={(value) => handleInputChange("difficulty", value)}
                    >
                      <SelectTrigger data-testid="quiz-difficulty-select">
                        <SelectValue placeholder="Select difficulty" />
                      </SelectTrigger>
                      <SelectContent>
                        {difficulties.map((difficulty) => (
                          <SelectItem key={difficulty.value} value={difficulty.value}>
                            {difficulty.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="topic">Topic (Optional)</Label>
                    <Input
                      id="topic"
                      value={formData.topic}
                      onChange={(e) => handleInputChange("topic", e.target.value)}
                      placeholder="e.g., Algebra, Photosynthesis"
                      data-testid="quiz-topic-input"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="num-questions">Number of Questions</Label>
                    <Select 
                      value={formData.numQuestions} 
                      onValueChange={(value) => handleInputChange("numQuestions", value)}
                    >
                      <SelectTrigger data-testid="quiz-questions-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3">3 Questions</SelectItem>
                        <SelectItem value="5">5 Questions</SelectItem>
                        <SelectItem value="10">10 Questions</SelectItem>
                        <SelectItem value="15">15 Questions</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={generateMutation.isPending}
                    data-testid="generate-quiz"
                  >
                    {generateMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <HelpCircle className="w-4 h-4 mr-2" />
                        Generate Quiz
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Generated Quiz Preview */}
            <Card className="xl:col-span-2" data-testid="quiz-preview">
              <CardHeader>
                <CardTitle>Quiz Preview</CardTitle>
              </CardHeader>
              <CardContent>
                {generateMutation.isPending ? (
                  <div className="flex items-center justify-center h-64">
                    <div className="text-center">
                      <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-primary" />
                      <p className="text-muted-foreground">Generating your quiz...</p>
                    </div>
                  </div>
                ) : generatedQuiz ? (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">{generatedQuiz.title}</h3>
                      <div className="flex gap-2 mb-4">
                        <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded">
                          {formData.subject}
                        </span>
                        <span className="px-2 py-1 bg-secondary/10 text-secondary text-xs rounded">
                          {formData.difficulty}
                        </span>
                        <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded">
                          {generatedQuiz.questions?.length || 0} questions
                        </span>
                      </div>
                    </div>
                    
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {generatedQuiz.questions?.map((question: QuizQuestion, index: number) => (
                        <div key={index} className="border border-border rounded-lg p-4" data-testid={`question-${index}`}>
                          <h4 className="font-medium mb-3">
                            {index + 1}. {question.question}
                          </h4>
                          <div className="space-y-2 mb-3">
                            {question.options?.map((option: string, optIndex: number) => (
                              <div 
                                key={optIndex} 
                                className={`p-2 rounded text-sm ${
                                  optIndex === question.correctAnswer 
                                    ? "bg-secondary/20 text-secondary border border-secondary/50" 
                                    : "bg-muted"
                                }`}
                              >
                                {String.fromCharCode(65 + optIndex)}. {option}
                              </div>
                            ))}
                          </div>
                          {question.explanation && (
                            <div className="text-xs text-muted-foreground bg-muted/50 p-2 rounded">
                              <strong>Explanation:</strong> {question.explanation}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-64 text-center">
                    <div>
                      <HelpCircle className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                      <p className="text-muted-foreground">
                        Generate a quiz to see the preview here.
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Existing Quizzes */}
          <Card className="mt-6" data-testid="existing-quizzes">
            <CardHeader>
              <CardTitle>Your Quizzes</CardTitle>
            </CardHeader>
            <CardContent>
              {quizzes.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No quizzes created yet. Generate your first quiz above!
                </p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {quizzes.map((quiz: any) => (
                    <div key={quiz.id} className="border border-border rounded-lg p-4" data-testid={`quiz-${quiz.id}`}>
                      <h4 className="font-medium mb-2">{quiz.title}</h4>
                      <div className="flex gap-2 mb-3">
                        <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded">
                          {quiz.subject}
                        </span>
                        <span className="px-2 py-1 bg-secondary/10 text-secondary text-xs rounded">
                          {quiz.difficulty}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mb-3">
                        {quiz.questions?.length || 0} questions
                      </p>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" data-testid={`edit-quiz-${quiz.id}`}>
                          <Edit className="w-3 h-3 mr-1" />
                          Edit
                        </Button>
                        <Button size="sm" variant="outline" data-testid={`delete-quiz-${quiz.id}`}>
                          <Trash2 className="w-3 h-3 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
