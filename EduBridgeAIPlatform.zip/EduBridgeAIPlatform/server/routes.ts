import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { aiService } from "./services/ai";
import { 
  insertChatSessionSchema,
  insertChatMessageSchema,
  insertQuizSchema,
  insertEducationalContentSchema,
  SUBJECTS,
  CONTENT_TYPES,
  DIFFICULTY_LEVELS
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get current user (demo user for now)
  app.get("/api/user/current", async (req, res) => {
    try {
      const user = await storage.getUser("demo-user-1");
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  // Get user statistics
  app.get("/api/user/stats", async (req, res) => {
    try {
      const stats = await storage.getUserStats("demo-user-1");
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get user stats" });
    }
  });

  // Chat Sessions
  app.get("/api/chat/sessions", async (req, res) => {
    try {
      const sessions = await storage.getChatSessionsByUser("demo-user-1");
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to get chat sessions" });
    }
  });

  app.post("/api/chat/sessions", async (req, res) => {
    try {
      const sessionData = insertChatSessionSchema.parse({
        ...req.body,
        userId: "demo-user-1"
      });
      const session = await storage.createChatSession(sessionData);
      res.json(session);
    } catch (error) {
      res.status(400).json({ message: "Invalid session data" });
    }
  });

  // Chat Messages
  app.get("/api/chat/sessions/:sessionId/messages", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getChatMessages(sessionId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to get chat messages" });
    }
  });

  app.post("/api/chat/sessions/:sessionId/messages", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messageData = insertChatMessageSchema.parse({
        ...req.body,
        sessionId
      });

      // Save user message
      const userMessage = await storage.createChatMessage(messageData);

      // Generate AI response
      const session = await storage.getChatSession(sessionId);
      const previousMessages = await storage.getChatMessages(sessionId);
      const context = previousMessages.slice(-4).map(m => `${m.role}: ${m.content}`);

      const aiResponse = await aiService.generateChatResponse(
        messageData.content,
        session?.subject || undefined,
        context
      );

      // Save AI response
      const aiMessage = await storage.createChatMessage({
        sessionId,
        role: "assistant",
        content: aiResponse.content
      });

      res.json({ userMessage, aiMessage });
    } catch (error) {
      console.error("Chat message error:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  // AI Chat (direct endpoint for quick responses)
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, subject, context } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const response = await aiService.generateChatResponse(message, subject, context);
      res.json(response);
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ message: "Failed to generate AI response" });
    }
  });

  // Quiz Generation
  app.post("/api/ai/generate-quiz", async (req, res) => {
    try {
      const { subject, difficulty, numQuestions, topic } = req.body;

      if (!subject || !difficulty) {
        return res.status(400).json({ message: "Subject and difficulty are required" });
      }

      if (!SUBJECTS.includes(subject)) {
        return res.status(400).json({ message: "Invalid subject" });
      }

      if (!DIFFICULTY_LEVELS.includes(difficulty)) {
        return res.status(400).json({ message: "Invalid difficulty level" });
      }

      const quiz = await aiService.generateQuiz(subject, difficulty, numQuestions, topic);
      
      // Save the generated quiz
      const savedQuiz = await storage.createQuiz({
        title: quiz.title,
        subject,
        difficulty,
        questions: quiz.questions,
        createdBy: "demo-user-1"
      });

      res.json(savedQuiz);
    } catch (error) {
      console.error("Quiz generation error:", error);
      res.status(500).json({ message: "Failed to generate quiz" });
    }
  });

  // Content Generation
  app.post("/api/ai/generate-content", async (req, res) => {
    try {
      const { type, subject, topic, gradeLevel } = req.body;

      if (!type || !subject || !topic) {
        return res.status(400).json({ message: "Type, subject, and topic are required" });
      }

      if (!CONTENT_TYPES.includes(type)) {
        return res.status(400).json({ message: "Invalid content type" });
      }

      if (!SUBJECTS.includes(subject)) {
        return res.status(400).json({ message: "Invalid subject" });
      }

      const content = await aiService.generateEducationalContent(type, subject, topic, gradeLevel);

      // Save the generated content
      const savedContent = await storage.createEducationalContent({
        title: content.title,
        type: content.type,
        subject,
        content: content.content,
        metadata: content.metadata,
        createdBy: "demo-user-1"
      });

      res.json(savedContent);
    } catch (error) {
      console.error("Content generation error:", error);
      res.status(500).json({ message: "Failed to generate content" });
    }
  });

  // Explanation Generation
  app.post("/api/ai/explain", async (req, res) => {
    try {
      const { concept, subject, level } = req.body;

      if (!concept || !subject) {
        return res.status(400).json({ message: "Concept and subject are required" });
      }

      const explanation = await aiService.generateExplanation(concept, subject, level);
      res.json({ explanation });
    } catch (error) {
      console.error("Explanation generation error:", error);
      res.status(500).json({ message: "Failed to generate explanation" });
    }
  });

  // Get Quizzes
  app.get("/api/quizzes", async (req, res) => {
    try {
      const { subject } = req.query;
      let quizzes;
      
      if (subject && SUBJECTS.includes(subject as any)) {
        quizzes = await storage.getQuizzesBySubject(subject as any);
      } else {
        quizzes = await storage.getQuizzesByUser("demo-user-1");
      }
      
      res.json(quizzes);
    } catch (error) {
      res.status(500).json({ message: "Failed to get quizzes" });
    }
  });

  // Get Educational Content
  app.get("/api/content", async (req, res) => {
    try {
      const { subject } = req.query;
      let content;
      
      if (subject && SUBJECTS.includes(subject as any)) {
        content = await storage.getContentBySubject(subject as any);
      } else {
        content = await storage.getContentByUser("demo-user-1");
      }
      
      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to get content" });
    }
  });

  // Subject Performance (mock data for now)
  app.get("/api/analytics/subject-performance", async (req, res) => {
    try {
      // In a real app, this would calculate actual performance metrics
      const performance = [
        { subject: "mathematics", score: 92, icon: "calculator", color: "blue" },
        { subject: "science", score: 88, icon: "flask", color: "green" },
        { subject: "language-arts", score: 85, icon: "book", color: "purple" },
        { subject: "history", score: 78, icon: "globe", color: "orange" }
      ];
      res.json(performance);
    } catch (error) {
      res.status(500).json({ message: "Failed to get subject performance" });
    }
  });

  // Recent Activity (mock data)
  app.get("/api/analytics/recent-activity", async (req, res) => {
    try {
      const activities = [
        {
          id: "1",
          type: "quiz",
          title: "Math Quiz: Algebra Basics",
          description: "Created 2 hours ago",
          icon: "file-alt",
          color: "primary"
        },
        {
          id: "2", 
          type: "completion",
          title: "Student completed Science quiz",
          description: "5 hours ago",
          icon: "user-graduate",
          color: "secondary"
        },
        {
          id: "3",
          type: "generation",
          title: "AI generated new content",
          description: "1 day ago", 
          icon: "robot",
          color: "accent"
        }
      ];
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to get recent activity" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
