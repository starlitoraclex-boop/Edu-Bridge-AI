import { GoogleGenAI } from "@google/genai";

// Using Gemini API instead of OpenAI
const genai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || ""
});

export interface ChatResponse {
  content: string;
  subject?: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface GeneratedQuiz {
  title: string;
  questions: QuizQuestion[];
}

export interface EducationalContentResponse {
  title: string;
  content: string;
  type: string;
  metadata?: any;
}

export class AIService {
  async generateChatResponse(
    message: string, 
    subject?: string, 
    context?: string[]
  ): Promise<ChatResponse> {
    try {
      const systemPrompt = this.buildTutorSystemPrompt(subject);
      const contextMessage = context && context.length > 0 
        ? `Previous conversation context: ${context.join('\n')}\n\n` 
        : '';

      const fullPrompt = `${systemPrompt}\n\n${contextMessage}${message}`;

      const response = await genai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: fullPrompt,
      });

      return {
        content: response.text || "I'm sorry, I couldn't generate a response.",
        subject: subject
      };
    } catch (error) {
      console.error("AI Service Error:", error);
      throw new Error("Failed to generate AI response. Please check your API configuration.");
    }
  }

  async generateQuiz(
    subject: string, 
    difficulty: string, 
    numQuestions: number = 5,
    topic?: string
  ): Promise<GeneratedQuiz> {
    try {
      const prompt = `Create a ${difficulty} level quiz for ${subject}${topic ? ` focusing on ${topic}` : ''} with ${numQuestions} multiple choice questions. 
      
      Respond with JSON in this exact format:
      {
        "title": "Quiz title",
        "questions": [
          {
            "question": "Question text",
            "options": ["Option A", "Option B", "Option C", "Option D"],
            "correctAnswer": 0,
            "explanation": "Why this answer is correct"
          }
        ]
      }`;

      const systemPrompt = "You are an expert educator who creates high-quality educational quizzes. Respond only with valid JSON.";

      const response = await genai.models.generateContent({
        model: "gemini-2.5-pro",
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              title: { type: "string" },
              questions: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    question: { type: "string" },
                    options: { type: "array", items: { type: "string" } },
                    correctAnswer: { type: "number" },
                    explanation: { type: "string" }
                  },
                  required: ["question", "options", "correctAnswer", "explanation"]
                }
              }
            },
            required: ["title", "questions"]
          }
        },
        contents: prompt,
      });

      const result = JSON.parse(response.text || "{}");
      return result as GeneratedQuiz;
    } catch (error) {
      console.error("Quiz Generation Error:", error);
      throw new Error("Failed to generate quiz. Please try again with different parameters.");
    }
  }

  async generateEducationalContent(
    type: string, 
    subject: string, 
    topic: string,
    gradeLevel?: string
  ): Promise<EducationalContentResponse> {
    try {
      const prompt = this.buildContentPrompt(type, subject, topic, gradeLevel);

      const systemPrompt = "You are an expert educational content creator.";

      const response = await genai.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          systemInstruction: systemPrompt
        },
        contents: prompt,
      });

      // Parse the JSON response manually since Gemini sometimes has issues with strict schemas
      const responseText = response.text || "{}";
      let result;
      try {
        result = JSON.parse(responseText);
      } catch (parseError) {
        // If JSON parsing fails, create a basic response
        result = {
          title: `${type.charAt(0).toUpperCase() + type.slice(1)} on ${topic}`,
          content: responseText,
          type: type,
          metadata: {
            subject: subject,
            topic: topic,
            gradeLevel: gradeLevel || 'general',
            estimatedTime: '15-30 minutes',
            difficulty: 'medium'
          }
        };
      }
      
      return result as EducationalContentResponse;
    } catch (error) {
      console.error("Content Generation Error:", error);
      throw new Error(`Failed to generate ${type}. Please verify your input and try again.`);
    }
  }

  async generateExplanation(concept: string, subject: string, level: string = "beginner"): Promise<string> {
    try {
      const prompt = `Explain the concept of "${concept}" in ${subject} for a ${level} level student. 
      Use clear, simple language with examples and analogies where appropriate. 
      Break down complex ideas into digestible parts.`;

      const systemPrompt = "You are a patient, knowledgeable tutor who excels at making complex topics understandable.";

      const response = await genai.models.generateContent({
        model: "gemini-2.5-flash",
        config: {
          systemInstruction: systemPrompt
        },
        contents: prompt,
      });

      return response.text || "Unable to generate explanation.";
    } catch (error) {
      console.error("Explanation Generation Error:", error);
      throw new Error("Failed to generate explanation. Please try again.");
    }
  }

  private buildTutorSystemPrompt(subject?: string): string {
    const basePrompt = `You are an AI tutor designed to help students learn effectively. You should:
    - Provide clear, accurate explanations
    - Use age-appropriate language
    - Encourage critical thinking
    - Offer step-by-step solutions for problems
    - Be patient and supportive
    - Ask follow-up questions to check understanding`;

    if (subject) {
      const subjectSpecific = {
        mathematics: "Focus on mathematical concepts, formulas, and problem-solving techniques. Show step-by-step solutions.",
        science: "Explain scientific concepts with real-world examples and encourage experimental thinking.",
        "language-arts": "Help with reading comprehension, writing skills, grammar, and literary analysis.",
        history: "Provide historical context, analyze cause and effect, and encourage critical thinking about past events."
      };

      return `${basePrompt}\n\nSubject Focus: ${subjectSpecific[subject as keyof typeof subjectSpecific] || "General education support"}`;
    }

    return basePrompt;
  }

  private buildContentPrompt(type: string, subject: string, topic: string, gradeLevel?: string): string {
    const gradeText = gradeLevel ? ` for ${gradeLevel} grade level` : '';
    
    const typePrompts = {
      "lesson-plan": `Create a comprehensive lesson plan for teaching "${topic}" in ${subject}${gradeText}. Include objectives, materials needed, activities, and assessment methods.`,
      "worksheet": `Design an educational worksheet for "${topic}" in ${subject}${gradeText}. Include varied question types and clear instructions.`,
      "explanation": `Write a detailed explanation of "${topic}" in ${subject}${gradeText}. Use clear language and include examples.`
    };

    const prompt = typePrompts[type as keyof typeof typePrompts] || 
      `Create educational content about "${topic}" in ${subject}${gradeText}.`;

    return `${prompt}

    Respond with JSON in this format:
    {
      "title": "Content title",
      "content": "Full content text with proper formatting",
      "type": "${type}",
      "metadata": {
        "subject": "${subject}",
        "topic": "${topic}",
        "gradeLevel": "${gradeLevel || 'general'}",
        "estimatedTime": "estimated completion time",
        "difficulty": "easy/medium/hard"
      }
    }`;
  }
}

export const aiService = new AIService();