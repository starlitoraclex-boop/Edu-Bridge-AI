import { 
  type User, 
  type InsertUser,
  type ChatSession,
  type InsertChatSession,
  type ChatMessage,
  type InsertChatMessage,
  type Quiz,
  type InsertQuiz,
  type QuizAttempt,
  type InsertQuizAttempt,
  type EducationalContent,
  type InsertEducationalContent,
  type Subject
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Chat Sessions
  getChatSession(id: string): Promise<ChatSession | undefined>;
  getChatSessionsByUser(userId: string): Promise<ChatSession[]>;
  createChatSession(session: InsertChatSession): Promise<ChatSession>;

  // Chat Messages
  getChatMessages(sessionId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;

  // Quizzes
  getQuiz(id: string): Promise<Quiz | undefined>;
  getQuizzesBySubject(subject: Subject): Promise<Quiz[]>;
  getQuizzesByUser(userId: string): Promise<Quiz[]>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;

  // Quiz Attempts
  getQuizAttempts(quizId: string): Promise<QuizAttempt[]>;
  getQuizAttemptsByUser(userId: string): Promise<QuizAttempt[]>;
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;

  // Educational Content
  getEducationalContent(id: string): Promise<EducationalContent | undefined>;
  getContentBySubject(subject: Subject): Promise<EducationalContent[]>;
  getContentByUser(userId: string): Promise<EducationalContent[]>;
  createEducationalContent(content: InsertEducationalContent): Promise<EducationalContent>;

  // Analytics
  getUserStats(userId: string): Promise<{
    activeStudents: number;
    aiInteractions: number;
    quizzesCreated: number;
    avgScore: number;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private chatSessions: Map<string, ChatSession> = new Map();
  private chatMessages: Map<string, ChatMessage> = new Map();
  private quizzes: Map<string, Quiz> = new Map();
  private quizAttempts: Map<string, QuizAttempt> = new Map();
  private educationalContent: Map<string, EducationalContent> = new Map();

  constructor() {
    // Initialize with a demo user
    const demoUser: User = {
      id: "demo-user-1",
      username: "John Doe",
      email: "john.doe@example.com",
      role: "educator",
      createdAt: new Date(),
    };
    this.users.set(demoUser.id, demoUser);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      role: insertUser.role || "student"
    };
    this.users.set(id, user);
    return user;
  }

  async getChatSession(id: string): Promise<ChatSession | undefined> {
    return this.chatSessions.get(id);
  }

  async getChatSessionsByUser(userId: string): Promise<ChatSession[]> {
    return Array.from(this.chatSessions.values()).filter(session => session.userId === userId);
  }

  async createChatSession(insertSession: InsertChatSession): Promise<ChatSession> {
    const id = randomUUID();
    const session: ChatSession = { 
      ...insertSession, 
      id, 
      createdAt: new Date(),
      subject: insertSession.subject || null
    };
    this.chatSessions.set(id, session);
    return session;
  }

  async getChatMessages(sessionId: string): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(message => message.sessionId === sessionId)
      .sort((a, b) => (a.timestamp?.getTime() || 0) - (b.timestamp?.getTime() || 0));
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = randomUUID();
    const message: ChatMessage = { ...insertMessage, id, timestamp: new Date() };
    this.chatMessages.set(id, message);
    return message;
  }

  async getQuiz(id: string): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }

  async getQuizzesBySubject(subject: Subject): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(quiz => quiz.subject === subject);
  }

  async getQuizzesByUser(userId: string): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(quiz => quiz.createdBy === userId);
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const id = randomUUID();
    const quiz: Quiz = { ...insertQuiz, id, createdAt: new Date() };
    this.quizzes.set(id, quiz);
    return quiz;
  }

  async getQuizAttempts(quizId: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values()).filter(attempt => attempt.quizId === quizId);
  }

  async getQuizAttemptsByUser(userId: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values()).filter(attempt => attempt.userId === userId);
  }

  async createQuizAttempt(insertAttempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const id = randomUUID();
    const attempt: QuizAttempt = { 
      ...insertAttempt, 
      id, 
      completedAt: new Date(),
      completed: insertAttempt.completed || false
    };
    this.quizAttempts.set(id, attempt);
    return attempt;
  }

  async getEducationalContent(id: string): Promise<EducationalContent | undefined> {
    return this.educationalContent.get(id);
  }

  async getContentBySubject(subject: Subject): Promise<EducationalContent[]> {
    return Array.from(this.educationalContent.values()).filter(content => content.subject === subject);
  }

  async getContentByUser(userId: string): Promise<EducationalContent[]> {
    return Array.from(this.educationalContent.values()).filter(content => content.createdBy === userId);
  }

  async createEducationalContent(insertContent: InsertEducationalContent): Promise<EducationalContent> {
    const id = randomUUID();
    const content: EducationalContent = { 
      ...insertContent, 
      id, 
      createdAt: new Date(),
      metadata: insertContent.metadata || {}
    };
    this.educationalContent.set(id, content);
    return content;
  }

  async getUserStats(userId: string): Promise<{
    activeStudents: number;
    aiInteractions: number;
    quizzesCreated: number;
    avgScore: number;
  }> {
    const userQuizzes = await this.getQuizzesByUser(userId);
    const userSessions = await this.getChatSessionsByUser(userId);
    const userAttempts = await this.getQuizAttemptsByUser(userId);
    
    const avgScore = userAttempts.length > 0 
      ? userAttempts.reduce((sum, attempt) => sum + attempt.score, 0) / userAttempts.length
      : 0;

    return {
      activeStudents: Array.from(this.users.values()).filter(u => u.role === "student").length,
      aiInteractions: userSessions.length * 5, // Estimate
      quizzesCreated: userQuizzes.length,
      avgScore: Math.round(avgScore * 100) / 100,
    };
  }
}

export const storage = new MemStorage();
